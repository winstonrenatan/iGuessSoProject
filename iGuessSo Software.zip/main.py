from tkinter import *
from tkinter import messagebox
from pickle import *

class Entity:
    def __init__(self, name, attr):
        self.name = name
        self.attr = attr

attribute_list = []
entity_list = []
answer_attr = []

# basic methods for debugging purposes (delete when finished)
def add_attr(new_attr):
    attribute_list.append(new_attr.lower())
    attribute_list.sort()

def add_entity(name, attr):
    attr.sort()
    entity_list.append(Entity(name, attr))

def guess(answer_attr):
    possible_answer = []
    for entity in entity_list:
        print(sorted(answer_attr), '\n', sorted(entity.attr))
        if sorted(answer_attr) == sorted(entity.attr):
            possible_answer.append(entity.name.title())
    return possible_answer

def pseudo_guess(answer_attr):
    possible_answer = []
    if len(answer_attr) > 0:
        for entity in entity_list:
            # print(sorted(answer_attr), '\n', sorted(entity.attr))
            viable = True
            for attr in answer_attr:
                if attr not in entity.attr:
                    viable = False
                    break
            if viable:
                possible_answer.append(entity.name.title())
            # print(possible_answer)
    else:
        return possible_answer

# showing main menu (duh)
def show_main_menu():
    root = Tk()
    MainMenu(root)
    root.mainloop()

# converting dictionary from entity.dat to entity_list and attribute.dat
# to attribute_list
def load_data():
    # loading entity data with error handling
    try:
        entity_data = open('entity.dat', 'rb')
    except FileNotFoundError:
          # messagebox.showinfo("Entity Data not Found!", "Entity Data not found! Making a new one.")
        entity_data = open('entity.dat', 'wb')
        dump({
            # entities
            # entity_name : [attr1, attr2]
            # apple : ['red', 'fruit']
        }, entity_data)
        entity_data = open('entity.dat', 'rb')

    # loading attribute data with error handling
    try:
        attribute_data = open('attribute.dat', 'rb')
    except FileNotFoundError:
          # messagebox.showinfo("Attribute Data not Found!", "Attribute Data not found! Making a new one.")
        attribute_data = open('attribute.dat', 'wb')
        dump({
            # attributes
            # 1 : attr1
            # 2 : attr2
            # 3 : attr3
        }, attribute_data)
        attribute_data = open('attribute.dat', 'rb')
    
    entity_dict = load(entity_data)
    attribute_dict = load(attribute_data)

    # inserting objects to entity_list
    entity_list = []
    for name in entity_dict:
        entity_list.append(Entity(name, entity_dict[name]))
    
    # inserting attributes to attribute_list
    attribute_list = []
    for idx in attribute_dict:
        attribute_list.append(attribute_dict[idx])
    
    # print for debugging purposes
    # print(entity_list, '\n', attribute_list)

    # closing file streams
    entity_data.close()
    attribute_data.close()
    
    return [entity_list, attribute_list]

def save_data():
    # convert to dictionary form (explained in load_data)
    save_entity = {}
    save_attribute = {}

    for entity in entity_list:
        save_entity[entity.name] = entity.attr

    for i in range(len(attribute_list)):
        save_attribute[i] = attribute_list[i]
    
    # save to entity.dat and attribute.dat
    entity_data = open('entity.dat', 'wb')
    attribute_data = open('attribute.dat', 'wb')

    dump(save_entity, entity_data)
    dump(save_attribute, attribute_data)

    entity_data = open('entity.dat', 'rb')
    attribute_data = open('attribute.dat', 'rb')

    # close file streams
    entity_data.close()
    attribute_data.close()

# MainMenu GUI Class
class MainMenu:
    def __init__(self, master):
        # window
        self.master = master
        self.master.title("iGuessSo")
        self.master.update()
        self.master.minsize(300, master.winfo_height())
        self.master.resizable(False, False)

        # preparing objects in frame
        self.title = Label(master, text="- iGuessSo -", font=("Arial", 16))
        self.separator = Frame(height=2, bd=1, relief=SUNKEN)
        self.guess_button = Button(master, text="Guess", command=self.guess_button_command)
        self.add_object_button = Button(master, text="Add an object", command=self.addobject_button_command)
        self.add_attr_button = Button(master, text="Add an attribute", command=self.addattribute_button_command)
        self.del_object_button = Button(master, text="Delete Object(s)", command=self.delobject_button_command)
        self.del_attribute_button = Button(master, text="Delete Attribute(s)", command=self.delattribute_button_command)
        self.quit_button = Button(master, text="Quit", command=master.destroy)

        # inserting objects
        self.title.pack(pady=10)
        self.separator.pack(fill=X, padx=5, pady=5)
        self.guess_button.pack(fill=X, padx=10, pady=5)
        self.add_object_button.pack(fill=X, padx=10, pady=5)
        self.add_attr_button.pack(fill=X, padx=10, pady=5)
        self.del_object_button.pack(fill=X, padx=10, pady=5)
        self.del_attribute_button.pack(fill=X, padx=10, pady=5)
        self.quit_button.pack(fill=X, padx=10, pady=5)
    
    def guess_button_command(self):
        if len(entity_list) == 0:
            messagebox.showerror("No Object Exists", "No object created yet. Add some first!")
            return
        if len(attribute_list) == 0:
            messagebox.showerror("No Attribute Exists", "No attribute created yet. Add some first!")
            return
        self.master.destroy()
        root = Tk()
        Guess(root)
        root.mainloop()
        # after playing and user decides to play another game, go to main menu again.

    def addobject_button_command(self):
        self.master.destroy()
        root = Tk()
        AddObject(root)
        root.mainloop()
    
    def addattribute_button_command(self):
        self.master.destroy()
        root = Tk()
        AddAttribute(root)
        root.mainloop()

    def delobject_button_command(self):
        self.master.destroy()
        root = Tk()
        DeleteObject(root)
        root.mainloop()
    
    def delattribute_button_command(self):
        self.master.destroy()
        root = Tk()
        DeleteAttribute(root)
        root.mainloop()

# Guess GUI Class
class Guess:
    def __init__(self, master):
        # window
        self.master = master
        self.master.resizable(False, False)
        self.master.update()
        self.master.minsize(300, 150)
        self.master.title("iGuessSo - Guessing...")
        
        # preparing objects in frame
        self.question_index = 0
        self.question_text = StringVar(value="Is the object {}?".format(attribute_list[self.question_index]))
        self.question_header_text = StringVar(value="Question #{}:".format(str(self.question_index+1)))
        self.question_header_label = Label(master, textvariable=self.question_header_text, font=("Arial", 14))
        self.question_label = Label(master, textvariable=self.question_text, font=("Arial", 12))
        self.separator = Frame(height=2, bd=1, relief=SUNKEN)
        self.yes_button = Button(master, text="YES", command=self.yes_command)
        self.no_button = Button(master, text="NO", command=self.no_command)
        self.answer = []

        # inserting objects
        self.question_header_label.pack()
        self.question_label.pack()
        self.separator.pack(fill=X, padx=5, pady=10)
        self.yes_button.pack(fill=X, padx=5, pady=5)
        self.no_button.pack(fill=X, padx=5, pady=5)
    
    def yes_command(self):
        # this is the command when player clicks YES in guessing phase
        try:
            self.answer.append(attribute_list[self.question_index])
            self.question_index += 1
            self.question_text.set("Is the object {}?".format(attribute_list[self.question_index]))
            self.question_header_text.set("Question #{}:".format(str(self.question_index+1)))
        except IndexError:
            self.finish()
    
    def yes_command2(self):
        # this is the command when player clicks YES in finished phase
        self.master.destroy()
        show_main_menu()

    
    def no_command(self):
        # this is the command when player clicks NO in guessing phase
        try:
            self.question_index += 1
            self.question_text.set("Is the object {}?".format(attribute_list[self.question_index]))
            self.question_header_text.set("Question #{}:".format(str(self.question_index+1)))
        except IndexError:
            self.finish()
    
    def no_command2(self):
        # this is the command when player clicks NO in finished phase
        self.master.destroy()

    def finish(self):
        self.master.title("iGuessSo - I've Guessed it!")
        self.master.geometry("400x300")

        # body
        possible_answer = guess(self.answer)
        for widget in self.master.winfo_children():
            widget.destroy()
        Label(self.master, text="I've guessed it!", font=("Arial", 14)).pack()
        Label(self.master, text="I think of:", font=("Arial", 12)).pack()
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
          # initialize canvas
        canvas_holder=Frame(self.master)
        self.canvas=Canvas(canvas_holder)
        canvas_content=Frame(self.canvas)
        scrollbar=Scrollbar(canvas_holder,orient="vertical",command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
          # insert canvas
        canvas_holder.pack()
        scrollbar.pack(side="right",fill="y")
        self.canvas.pack(side="left")
        self.canvas.create_window((0,0), window=canvas_content, anchor='nw')
        canvas_content.bind("<Configure>",self.canvas_configure_callback)
        if len(possible_answer)>0:
            for ans in possible_answer:
                Label(canvas_content, text=ans).pack(anchor=W)
        else:
            Label(canvas_content, text="Nothing :(").pack(anchor=W)
            if len(possible_answer) > 0:
                Label(canvas_content, text="However, There are things that resembles your attributes:").pack(anchor=W)
                possible_answer = pseudo_guess(self.answer)
                for ans in possible_answer:
                    Label(canvas_content, text=ans).pack(anchor=W)

        
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        Label(self.master, text="Go back to main menu?").pack()

        # button creation
        yes_button = Button(self.master, text="YES", command=self.yes_command2)
        no_button = Button(self.master,  text="Quit", command=self.no_command2)

        # insert button to window
        yes_button.pack(fill=X, padx=5, pady=5)
        no_button.pack(fill=X, padx=5, pady=5)
    
    def canvas_configure_callback(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"),width=400,height=115)


# AddObject GUI Class
class AddObject:
    def __init__(self, master):
        self.master = master
        self.master.update()
        self.master.minsize(master.winfo_width(), master.winfo_height())
        self.master.title("iGuessSo - Add Object")

        # an array that corresponds to checkbuttons
        self.checkbutton_vars = []
        for i in range(len(attribute_list)):
            self.checkbutton_vars.append(IntVar())

        # create objects (and occassionally insert)
        page_title = Label(self.master, text="Add an Object", font=("Arial", 14))
        object_name_label = Label(self.master, text="Object Name:")
        self.object_name_textbox = Entry(self.master)
        attribute_select_label = Label(self.master, text="Select Attribute(s):")
        canvas_holder=Frame(self.master)
        self.canvas=Canvas(canvas_holder)
        canvas_content=Frame(self.canvas)
        scrollbar=Scrollbar(canvas_holder,orient="vertical",command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        create_object_button = Button(self.master, text="Add Object", command=self.add_object_command)
        main_menu_button = Button(self.master, text="Main Menu", command=self.main_menu_command)
        
        # insert objects
        page_title.pack()
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        object_name_label.pack()
        self.object_name_textbox.pack(fill=X, padx=70)
        attribute_select_label.pack(pady=5)
        canvas_holder.pack()
        scrollbar.pack(side="right",fill="y")
        self.canvas.pack()
        self.canvas.create_window((0,0), window=canvas_content, anchor='nw')
        canvas_content.bind("<Configure>",self.canvas_configure_callback)
        for i in range(len(attribute_list)):
            Checkbutton(canvas_content, text=attribute_list[i].title(), variable=self.checkbutton_vars[i]).pack(anchor=W)
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        create_object_button.pack(fill=X, padx=5, pady=5)
        main_menu_button.pack(fill=X, padx=5, pady=5)

    def canvas_configure_callback(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"),width=300,height=200)

    def main_menu_command(self):
        # this is the command when player clicks Main Menu button
        self.master.destroy()
        show_main_menu()

    def add_object_command(self):
        attributes = []

        # duplicate checking
        for entity in entity_list:
            if entity.name.lower() == self.object_name_textbox.get().lower():
                messagebox.showerror("Duplicate Object!", "I have detected that you just entered a duplicate object. Please change the object name and try again.")
                self.object_name_textbox.config({"background": "misty rose"})
                return
        self.object_name_textbox.config({"background": "white"})
        
        for i in range(len(attribute_list)):
            if self.checkbutton_vars[i].get() == 1: # if checkbutton is checked
                attributes.append(attribute_list[i])
        add_entity(self.object_name_textbox.get(), attributes)
        messagebox.showinfo("Object Created!", "Object has been inserted successfully!")
        save_data()
          # print(entity_list, '\n', attribute_list)
        self.master.destroy()
        root = Tk()
        AddObject(root)
        root.mainloop()

# AddAttribute GUI Class
class AddAttribute:
    def __init__(self, master):
        self.master = master
        self.master.update()
        self.master.minsize(master.winfo_width(), master.winfo_height())
        self.master.resizable(False, False)
        self.master.title("iGuessSo - Add Attribute")

        # an array that corresponds to checkbuttons
        self.checkbutton_vars = []
        for i in range(len(entity_list)):
            self.checkbutton_vars.append(IntVar())

        # create objects (and occassionally insert)
        page_title = Label(self.master, text="Add an Attribute", font=("Arial", 14))
        attribute_name_label = Label(self.master, text="Attribute Name:")
        self.attribute_name_textbox = Entry(self.master)
        attribute_select_label = Label(self.master, text="Select Entity(ies) with that attribute:")
        canvas_holder=Frame(self.master)
        self.canvas=Canvas(canvas_holder)
        canvas_content=Frame(self.canvas)
        scrollbar=Scrollbar(canvas_holder,orient="vertical",command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        create_attribute_button = Button(self.master, text="Add Attribute", command=self.add_attribute_command)
        main_menu_button = Button(self.master, text="Main Menu", command=self.main_menu_command)
        
        # insert objects
        page_title.pack()
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        attribute_name_label.pack()
        self.attribute_name_textbox.pack(fill=X, padx=70)
        attribute_select_label.pack(pady=5)
        canvas_holder.pack()
        scrollbar.pack(side="right",fill="y")
        self.canvas.pack(side="left")
        self.canvas.create_window((0,0), window=canvas_content, anchor='nw')
        canvas_content.bind("<Configure>",self.canvas_configure_callback)
        for i in range(len(entity_list)):
            Checkbutton(canvas_content, text=entity_list[i].name.title(), variable=self.checkbutton_vars[i]).pack(anchor=W)
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        create_attribute_button.pack(fill=X, padx=5, pady=5)
        main_menu_button.pack(fill=X, padx=5, pady=5)

    def canvas_configure_callback(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"),width=300,height=200)

    def main_menu_command(self):
        # this is the command when player clicks Main Menu button
        self.master.destroy()
        show_main_menu()

    def add_attribute_command(self):
        # duplicate checking
        for attr in attribute_list:
            if self.attribute_name_textbox.get().lower() == attr.lower():
                messagebox.showerror("Duplicate Attribute!", "I have detected that you just entered a duplicate attribute. Please change the attribute name and try again.")
                self.attribute_name_textbox.config({"background": "misty rose"})
                return
        self.attribute_name_textbox.config({"background": "white"})

        for i in range(len(entity_list)):
            if self.checkbutton_vars[i].get() == 1: # if checkbutton is checked
                if self.attribute_name_textbox.get().lower() not in entity_list[i].attr: # duplicate handling
                    entity_list[i].attr.append(self.attribute_name_textbox.get().lower())
        add_attr(self.attribute_name_textbox.get())
        messagebox.showinfo("Attribute Created!", "Attribute has been inserted successfully!")
        save_data()
          # print(entity_list, '\n', attribute_list)
        self.master.destroy()
        root = Tk()
        AddAttribute(root)
        root.mainloop()
    
# DeleteObject GUI Class
class DeleteObject:
    def __init__(self, master):
        self.master = master
        self.master.update()
        self.master.minsize(master.winfo_width(), master.winfo_height())
        self.master.title("iGuessSo - Delete Objects")

        # an array that corresponds to checkbuttons
        self.checkbutton_vars = []
        for i in range(len(entity_list)):
            self.checkbutton_vars.append(IntVar())

        # create objects
        page_title = Label(self.master, text="Delete Objects", font=("Arial", 14))
        object_select_label = Label(self.master, text="Select Object(s) to be Deleted:")
        canvas_holder=Frame(self.master)
        self.canvas=Canvas(canvas_holder)
        canvas_content=Frame(self.canvas)
        scrollbar=Scrollbar(canvas_holder,orient="vertical",command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        delete_object_button = Button(self.master, text="Delete Object(s)", command=self.delete_object_command)
        main_menu_button = Button(self.master, text="Main Menu", command=self.main_menu_command)

        # insert objects
        page_title.pack()
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        object_select_label.pack()
        canvas_holder.pack()
        scrollbar.pack(side="right",fill="y")
        self.canvas.pack()
        self.canvas.create_window((0,0), window=canvas_content, anchor='nw')
        canvas_content.bind("<Configure>",self.canvas_configure_callback)
        for i in range(len(entity_list)):
            Checkbutton(canvas_content, text=entity_list[i].name.title(), variable=self.checkbutton_vars[i]).pack(anchor=W)
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        delete_object_button.pack(fill=X, padx=5, pady=5)
        main_menu_button.pack(fill=X, padx=5, pady=5)

    def main_menu_command(self):
        # this is the command when player clicks Main Menu button
        self.master.destroy()
        show_main_menu()
    
    def canvas_configure_callback(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"),width=300,height=200)

    def delete_object_command(self):
        offset = 0
        for i in range (len(self.checkbutton_vars)):
            if self.checkbutton_vars[i].get() == 1:
                  # print(str(i-offset), ":", entity_list[i-offset].name.title())
                del entity_list[i-offset]
                offset += 1

        save_data()
          # print(entity_list, '\n', attribute_list)
        self.master.destroy()
        root = Tk()
        DeleteObject(root)
        root.mainloop()

# DeleteAttribute GUI Class
class DeleteAttribute:
    def __init__(self, master):
        self.master = master
        self.master.update()
        self.master.minsize(master.winfo_width(), master.winfo_height())
        self.master.title("iGuessSo - Delete Attributes")

        # an array that corresponds to checkbuttons
        self.checkbutton_vars = []
        for i in range(len(attribute_list)):
            self.checkbutton_vars.append(IntVar())

        # create objects
        page_title = Label(self.master, text="Delete Attributes", font=("Arial", 14))
        object_select_label = Label(self.master, text="Select Attribute(s) to be Deleted:")
        canvas_holder=Frame(self.master)
        self.canvas=Canvas(canvas_holder)
        canvas_content=Frame(self.canvas)
        scrollbar=Scrollbar(canvas_holder,orient="vertical",command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        delete_object_button = Button(self.master, text="Delete Attribute(s)", command=self.delete_attribute_command)
        main_menu_button = Button(self.master, text="Main Menu", command=self.main_menu_command)

        # insert objects
        page_title.pack()
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        object_select_label.pack()
        canvas_holder.pack()
        scrollbar.pack(side="right",fill="y")
        self.canvas.pack()
        self.canvas.create_window((0,0), window=canvas_content, anchor='nw')
        canvas_content.bind("<Configure>",self.canvas_configure_callback)
        for i in range(len(attribute_list)):
            Checkbutton(canvas_content, text=attribute_list[i].title(), variable=self.checkbutton_vars[i]).pack(anchor=W)
        Frame(height=2, bd=1, relief=SUNKEN).pack(fill=X, padx=5, pady=5)
        delete_object_button.pack(fill=X, padx=5, pady=5)
        main_menu_button.pack(fill=X, padx=5, pady=5)

    def main_menu_command(self):
        # this is the command when player clicks Main Menu button
        self.master.destroy()
        show_main_menu()
    
    def canvas_configure_callback(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"),width=300,height=200)

    def delete_attribute_command(self):
        offset = 0
        for i in range (len(self.checkbutton_vars)):
            if self.checkbutton_vars[i].get() == 1:
                  # print(str(i-offset), ":", attribute_list[i-offset].title())
                for entity in entity_list:
                    if attribute_list[i-offset] in entity.attr:
                        del entity.attr[entity.attr.index(attribute_list[i-offset])]
                del attribute_list[i-offset]
                offset += 1

        save_data()
          # print(entity_list, '\n', attribute_list)
        self.master.destroy()
        root = Tk()
        DeleteAttribute(root)
        root.mainloop()

if __name__ == "__main__":
    data = load_data()
    entity_list = data[0]
    attribute_list = data[1]
    show_main_menu()