from openpyxl import *
from pickle import *

entity = open('entity.dat', 'wb')
attribute = open('attribute.dat', 'wb')

data = {
    # animal_name : [attr1, attr2]
}

attr = {
    # col_num : attr_name
}

wb = load_workbook('awa2.xlsx')
ws = wb['Sheet1']

row = '1'
col = 'B'

# rows (animal name insert to dict)
for i in range(2, 52, 1):
    data[ws.cell(row=i, column=1).value] = []

# insert to dictionary so that we can directly insert attr to data
for i in range(2, 86, 1):
    attr[i] = ws.cell(row=1, column=i).value

# cols (animal attribute insert to dict)
for i in range (2, 52, 1):
    for j in range(2, 86, 1):
        if str(ws.cell(row=i, column=j).value) == str(1):
            data[ws.cell(row=i, column=1).value].append(attr[j])

print(data, '\n', attr)

dump(data, entity)
dump(attr, attribute)